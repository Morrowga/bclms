export const Skins = {
  Default: 'default',
  Bordered: 'bordered',
}
export const RouteTransitions = {
  // 'Zoom Fade': 'app-transition-zoom-fade',
  // 'Fade Bottom': 'app-transition-fade-bottom',
  // 'Slide Fade': 'app-transition-slide-fade',
  // 'Zoom out': 'app-transition-zoom-out',
  Fade: 'app-transition-fade',
  None: 'none',
}
