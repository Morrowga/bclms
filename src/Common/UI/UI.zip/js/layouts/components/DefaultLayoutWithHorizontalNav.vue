<script setup>
import navItems from "@/navigation/horizontal";
import { useThemeConfig } from "@core/composable/useThemeConfig";
import { themeConfig } from "@themeConfig";

// Components
import Footer from "@/layouts/components/Footer.vue";
import NavBarNotifications from "@/layouts/components/NavBarNotifications.vue";
import NavbarShortcuts from "@/layouts/components/NavbarShortcuts.vue";
import NavbarThemeSwitcher from "@/layouts/components/NavbarThemeSwitcher.vue";
import NavSearchBar from "@/layouts/components/NavSearchBar.vue";
import UserProfile from "@/layouts/components/UserProfile.vue";
import { HorizontalNavLayout } from "@layouts";
import { VNodeRenderer } from "@layouts/components/VNodeRenderer";

const { appRouteTransition } = useThemeConfig();
import { Link } from "@inertiajs/inertia-vue3";
</script>

<template>
  <HorizontalNavLayout :nav-items="navItems">
    <!-- 👉 navbar -->
    <template #navbar>
      <v-app-bar elevation="0">
        <Link to="/" class="d-flex align-start gap-x-2">
          <VNodeRenderer :nodes="themeConfig.app.logo" />
          <h1 class="font-weight-bold leading-normal text-xl">
            {{ themeConfig.app.title }}
          </h1>
        </Link>
        <VSpacer />

        <NavbarThemeSwitcher class="me-1" />
        <NavbarShortcuts class="me-1" />
        <NavBarNotifications class="me-3" />
        <UserProfile />
      </v-app-bar>
    </template>

    <!-- 👉 Pages -->
    <slot>
      <Transition :name="appRouteTransition" mode="out-in">
        <h1>Hello World</h1>
      </Transition>
    </slot>
    <!-- 👉 Footer -->
    <template #footer>
      <Footer />
    </template>

    <!-- 👉 Customizer -->
    <!-- <TheCustomizer /> -->
  </HorizontalNavLayout>
</template>
